"""Weapon categories, atomic firing modes and condition-dependent attacks."""
from game import items as item_rules
import module_rules

import math
import content; import hexgrid; import balance

from i18n import t as tr

def category(item):
    return content.EQUIPMENT.get(item.get('type_id'),{}).get('category','pistol') if item else 'pistol'

def modes(item):
    kind=category(item)
    return ('single','burst') if kind=='automatic' else ('aimed',) if kind=='sniper' else ('single',)

def shot_cost(item):
    allowed=modes(item);mode=item.get('fire_mode',allowed[0])
    if mode not in allowed:mode=allowed[0]
    return item.get('ap',2)+int(mode in ('aimed','burst'))

def misfire_chance(item):
    condition=module_rules.condition(item)
    return 0 if condition>=75 else .02 if condition>=50 else .05

def behind(source,target,pos):
    """A narrow axial-space cone extending at most three hexes beyond the target."""
    def point(a):return (a[0]+a[1]*.5,a[1]*math.sqrt(3)/2)
    a,b,c=map(point,(source,target,pos));dx,dy=b[0]-a[0],b[1]-a[1];length=math.hypot(dx,dy)
    if not length:return False
    vx,vy=c[0]-b[0],c[1]-b[1]
    return 0<(vx*dx+vy*dy)/length<=3.1 and abs(vx*dy-vy*dx)/length<=1.1

def projectile_components(weapon,level,enemy,variation,critical,pellet=None,multiplier=1):
    """Pure damage formula shared by combat and weapon previews."""
    from game.systems.adventure import damage_type,RESISTANCES
    stats=item_rules.stats(weapon)
    components=module_rules.shot_components(weapon,level,variation,damage_type(weapon))
    dealt={}
    for element,raw in components.items():
        base=balance.damage(raw*(1.6 if critical else 1),stats.get('attack',0),enemy.get('defense',enemy.get('armor',0)))
        resist=enemy.get('resists',RESISTANCES.get(enemy.get('kind'),{})).get(element,0)
        amount=max(1,round(base*(1-resist/100))) if raw else 0
        if amount:amount=max(1,round(amount*multiplier))
        if pellet is not None:amount=amount//6+int(pellet<amount%6)
        dealt[element]=amount
    return dealt


class Combat:
    def fire_modes(self,weapon=None):
        """Return modes available for the selected weapon category."""
        return modes(weapon or self.weapon)

    def fire_mode(self,weapon=None):
        """Resolve the stored mode, repairing obsolete modes without mutating an item."""
        weapon=weapon or self.weapon;allowed=modes(weapon)
        value=weapon.get('fire_mode') if weapon else None
        return value if value in allowed else allowed[0]

    def cycle_fire_mode(self):
        """Switch between single and burst without spending AP."""
        if not self.battle or not self.weapon or len(self.fire_modes())<2:return False
        self.weapon['fire_mode']='burst' if self.fire_mode()=='single' else 'single';return True

    def shot_ap(self,weapon=None):
        """Calculate AP including automatic burst or aimed-shot surcharge."""
        weapon=weapon or self.weapon
        return shot_cost(weapon) if weapon else 0

    def shot_info(self,enemy):
        """Keep range/line-of-sight rules and apply mode accuracy in percentage points."""
        valid,reason,chance=super().shot_info(enemy)
        if valid:
            mode=self.fire_mode()
            if mode=='burst':chance-=15
            elif mode=='aimed':chance+=-30 if hexgrid.distance(self.battle['pos'],enemy['pos'])<4 else 10
            chance=max(1,min(98,chance))
        return valid,reason,chance

    def _projectile_damage(self,enemy,weapon,mode,pellet=None,scale=1):
        """Resolve one bullet or one sixth of a shotgun shell after defense/resistance.

        `scale` is the shotgun's range falloff for this pellet.
        """
        from game.systems.adventure import damage_type,RESISTANCES,DAMAGE_TYPES
        effective=module_rules.effective_weapon(self,weapon)
        stats=item_rules.stats(effective);critical=self.rng.randrange(100)<(min(65,5+stats.get('crit',0))+(15 if mode=='aimed' else 0))
        dealt=projectile_components(effective,self.level,enemy,self.rng.randint(-2,2),critical,pellet,getattr(self,'outgoing_damage_multiplier',1)*scale)
        amount=sum(dealt.values())
        __import__('battle_results').hit(self,'dealt',amount,enemy['hp'])
        enemy['hp']-=amount;enemy['awake']=True
        self.emit((tr('adventure.0217') if critical else '')+f'−{amount}',pos=enemy['pos'],color='#ffbf82' if critical else '#ff9d84')
        if hasattr(self,'mark_hit'):self.mark_hit(enemy,amount)
        self.log(f'{enemy["name"]}: −{amount} HP ('+', '.join(f'{DAMAGE_TYPES[k][0]}: {v}' for k,v in dealt.items())+').')
        if enemy['hp']<=0:self._finish_enemy(enemy,weapon)

    def shoot(self,enemy_id):
        """Spend AP/ammunition once, animate every projectile and finish all hits before victory."""
        b=self.battle;w=self.weapon
        if not b or not w:return False
        target=next((e for e in b['enemies'] if e['id']==enemy_id),None)
        if not target:return False
        valid,why,chance=self.shot_info(target);mode=self.fire_mode();bullets=5 if mode=='burst' else 1
        ammo=w.get('ammo_type','pistol');reason=None
        if module_rules.condition(w)<=0:reason=tr('adventure.0213')
        elif self.count('ammo',ammo)<bullets:reason=tr('update033.ammo_need',qty=bullets)
        elif b['ap']<self.shot_ap():reason=tr('adventure.0215')
        elif not valid:reason=why
        if reason:self.log(reason);self.emit(reason,color='#ffcb79');return False
        from damage_preview import remember_target
        remember_target(self,target)
        b['ap']-=self.shot_ap();saved=module_rules.chance(module_rules.weapon_stats(self,w).get('ammo_save_percent',0))
        for _ in range(bullets):
            if saved and self.rng.random()*100<saved:self.emit(tr('modules.ammo_saved'),color='#9cdcd8')
            else:self.consume('ammo',1,ammo)
        shell=category(w)=='shotgun'
        if shell:
            self._shotgun_shell(target,w,mode,chance)
        else:
            self._bullets(target,w,mode,chance,bullets)
        target['awake']=True
        self.wear(w,.6*bullets*(2 if mode=='aimed' else 1))
        if not b['enemies']:self.victory()
        return True

    def _bullets(self,target,w,mode,chance,bullets):
        """A single bullet rolls the hit chance; a burst flies as a widening fan (see burst.py)."""
        if mode=='burst':return self._burst(target,w,chance)
        from game.systems.adventure import damage_type,DAMAGE_TYPES,attack_look
        b=self.battle
        volley=__import__('uuid').uuid4().hex
        misfire=self.rng.random()<misfire_chance(w) if misfire_chance(w) else False
        stray=None
        if misfire:
            self.emit(tr('update033.jam'),color='#ffc46e')
            pool=[e for e in b['enemies'] if e is not target and (not hasattr(self,'hostile_to_player') or self.hostile_to_player(e)) and hexgrid.distance(b['pos'],e['pos'])<=module_rules.weapon_stats(self,w)['range'] and hexgrid.visible(tuple(b['pos']),tuple(e['pos']),b['walls'])]
            if pool and self.rng.random()<.25:stray=self.rng.choice(pool)
        for n in range(bullets):
            hit=None
            if misfire:
                if stray in b['enemies'] and self.rng.randrange(100)<chance:hit=stray
            elif target in b['enemies'] and self.rng.randrange(100)<max(1,chance):hit=target
            pos=(hit or target)['pos']
            self.emit(kind='attack',pos=pos,source=b['pos'],color=DAMAGE_TYPES[damage_type(w)][1])
            self._events[-1].update(fire_mode=mode,projectile=n,volley=volley,volley_count=bullets,damage_type=damage_type(w),hit=bool(hit),**attack_look(w))
            if hit:self._projectile_damage(hit,w,mode,None)
            else:self.emit(tr('adventure.0218'),pos=pos,color='#d7d4c0')

    def _burst(self,target,w,chance):
        """Five bullets one after another, each wider; the first hostile body on the way takes it."""
        from game.systems.adventure import damage_type,DAMAGE_TYPES,attack_look
        from game.systems import burst
        b=self.battle;limit=module_rules.weapon_stats(self,w)['range']
        misfire=self.rng.random()<misfire_chance(w) if misfire_chance(w) else False
        if misfire:self.emit(tr('update033.jam'),color='#ffc46e')
        shots=burst.volley(self,target,chance,self.rng,limit,wild=misfire)
        volley=__import__('uuid').uuid4().hex;hits={}
        for n,(enemy,end,distance,wall) in enumerate(shots):
            self.emit(kind='attack',pos=enemy['pos'] if enemy else end,source=b['pos'],color=DAMAGE_TYPES[damage_type(w)][1])
            self._events[-1].update(fire_mode='burst',projectile=n,volley=volley,volley_count=burst.BULLETS,
                                    damage_type=damage_type(w),hit=enemy is not None,wall=wall,**attack_look(w))
            if enemy is None or enemy not in b['enemies']:continue
            hits[enemy['id']]=hits.get(enemy['id'],0)+1
            self._projectile_damage(enemy,w,'burst',None)
        if not hits:self.emit(tr('adventure.0218'),pos=target['pos'],color='#d7d4c0')
        self._last_burst=dict(hits=hits,bullets=len(shots))

    def _shotgun_shell(self,target,w,mode,chance):
        """Six pellets in a fan: each takes the first hostile body on its way (see shotgun.py)."""
        from game.systems.adventure import damage_type,DAMAGE_TYPES,attack_look
        from game.systems import shotgun
        b=self.battle;limit=module_rules.weapon_stats(self,w)['range']
        misfire=self.rng.random()<misfire_chance(w) if misfire_chance(w) else False
        if misfire:self.emit(tr('update033.jam'),color='#ffc46e')
        pellets=shotgun.fan(self,target,chance,self.rng,limit,w,wild=misfire)
        volley=__import__('uuid').uuid4().hex;hits={}
        for n,(enemy,end,distance,wall) in enumerate(pellets):
            self.emit(kind='attack',pos=enemy['pos'] if enemy else end,source=b['pos'],color=DAMAGE_TYPES[damage_type(w)][1])
            self._events[-1].update(fire_mode='pellet',projectile=n,volley=volley,volley_count=shotgun.PELLETS,wall=wall,
                                    damage_type=damage_type(w),hit=enemy is not None,**attack_look(w))
            if enemy is None or enemy not in b['enemies']:continue
            hits[enemy['id']]=hits.get(enemy['id'],0)+1
            self._projectile_damage(enemy,w,mode,n,shotgun.falloff(w,distance,limit))
        if not hits:self.emit(tr('adventure.0218'),pos=target['pos'],color='#d7d4c0')
        for enemy in list(b['enemies']):
            if hits.get(enemy['id'],0)>=shotgun.KNOCKBACK and enemy['hp']>0:
                dest=shotgun.knockback(self,enemy)
                if dest:
                    self.emit_move([enemy['pos'],dest],enemy['id']);enemy['pos']=dest
                    self.emit(tr('update033.knockback'),pos=dest,color='#ffcf8a')
        self._last_shell=dict(hits=hits,pellets=len(pellets))
