"""Exercise all content-editor sections on temporary catalogs, never live data."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tempfile
import tkinter as tk
from tkinter import ttk
from unittest.mock import patch
from tests.test_entity_editor import project_copy
from content_editor import ContentEditor
import entity_catalog as catalog

def run(capture=None):
    with tempfile.TemporaryDirectory() as folder:
        root_path=project_copy(folder)
        root=tk.Tk();ttk.Style(root).theme_use('clam')
        try:
            app=ContentEditor(root,root_path/'data/road_events.json',root_path);root.update()
            assert len(app.tabs.tabs())>=10,len(app.tabs.tabs())
            assert app.commit() and not app.store.dirty,'Opening unchanged sections must not alter catalogs'
            app.items.open('item_credits');app.items.variables['sprite_id'].set('med');root.update()
            assert app.items.image is not None
            assert str(app.items.widgets['weight'].cget('state'))=='disabled'
            assert app.items.commit()
            app.tabs.select(app.items);root.update()
            assert app.tabs.index(app.items)==app.tabs.index(app.panels['module'])+1
            app.items.open('item_food');app.items.variables['satiety'].set('6');app.items.variables['heal'].set('4')
            assert app.items.commit()
            app.items.add();custom_item=app.items.current
            app.items.variables['name'].set('Комбінований пайок')
            app.events.fields['title'].set('Тест спільного збереження')
            for section,panel in app.panels.items():
                app.tabs.select(panel);root.update();initial=len(app.store.items(section))
                before=panel.table.item(panel.table.get_children()[0])['values']
                panel.level.set('15');panel.refresh_preview();root.update()
                assert panel.table.get_children() and not panel.preview_error.get()
                with patch('entity_editor.simpledialog.askstring',return_value='Тестова модель '+section):panel.new()
                assert len(app.store.items(section))==initial+1
                panel.duplicate();assert len(app.store.items(section))==initial+2
                field={'weapon':'damage','armor':'defense','helmet':'defense','module':'base','monster':'hp'}[section]
                panel.fields[field].set('51');panel.refresh_preview();root.update()
                if section=='weapon':
                    # Attack animation: empty means "by damage type"; a chosen look is saved with the weapon.
                    assert panel.fields['projectile'].get()==catalog.PROJECTILES['']
                    panel.fields['projectile'].set(catalog.PROJECTILES['railgun'])
                if section=='monster':
                    panel.fields['base_level'].set('7');panel.refresh_preview();root.update()
                    assert panel.level.get()=='7'
                assert panel.commit()
                if capture:
                    import time
                    from PIL import ImageGrab
                    root.lift();root.update();time.sleep(.4);root.update()
                    target=Path(capture);target.mkdir(parents=True,exist_ok=True)
                    ImageGrab.grab(bbox=(root.winfo_rootx(),root.winfo_rooty(),root.winfo_rootx()+root.winfo_width(),root.winfo_rooty()+root.winfo_height())).save(target/(section+'_editor.png'))
            assert app.save_all()
            loaded=catalog.Store(root_path)
            assert loaded.data['consumables']['item_credits']['sprite_id']=='med'
            assert loaded.data['consumables'][custom_item]['heal']==4
            assert loaded.data['consumables'][custom_item]['satiety']==6
            assert loaded.data['consumables'][custom_item]['name']=='Комбінований пайок'
            assert not loaded.validate()
            import event_catalog
            saved_events=event_catalog.load(root_path/'data/road_events.json')
            assert any(e['id']==app.events.current and e['title']=='Тест спільного збереження' for e in saved_events['events'])
            for section,panel in app.panels.items():assert loaded.data[catalog.GROUPS[section]][panel.current][{'weapon':'damage','armor':'defense','helmet':'defense','module':'base','monster':'hp'}[section]]==51
            assert loaded.data['equipment'][app.panels['weapon'].current]['projectile']=='railgun'
            assert all('projectile' not in d for k,d in loaded.data['equipment'].items() if k!=app.panels['weapon'].current and d['kind']=='weapon' and k in catalog.Store(Path(__file__).resolve().parents[1]).baseline['equipment'])
            panel=app.panels['weapon'];panel.fields['damage'].set('invalid')
            with patch('entity_editor.messagebox.showerror') as error:
                assert not app.save_all() and error.called
            print('Content editor UI: all sections, create, duplicate, preview, save/reload and validation passed')
        finally:root.destroy()

if __name__=='__main__':run(sys.argv[1] if len(sys.argv)>1 else None)
